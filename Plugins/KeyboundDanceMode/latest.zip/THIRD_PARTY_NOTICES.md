# 第三方来源说明

本项目按 GNU Affero General Public License v3.0 or later 发布，完整文本见 `LICENSE`。

## DailyRoutines

- 作者及贡献者：AtmoOmen 与 DailyRoutines contributors。
- 项目：https://github.com/AtmoOmen/DailyRoutines
- 许可：AGPL-3.0-or-later。
- 参考：魔光键影拼音显示模块、自动游玩模块的词条有效性检查与机制入口，以及游戏窗口消息钩子的调用形式。
- 本项目重新实现为独立的玩家按键玩法；不分发或依赖 DR 的 DLL。

## FFXIVClientStructs.Expansion / FFXIVClientStructs

- 参考项目：https://github.com/AtmoOmen/FFXIVClientStructs.Expansion
- 基础项目：https://github.com/aers/FFXIVClientStructs
- 参考内容：魔光键影代理、词条窗口、词条项和副本控制器的结构布局及函数签名。
- 原始许可：MIT，完整许可及版权声明保存在 `licenses/FFXIVClientStructs.Expansion-MIT.txt`。
- 本项目仅保存所需的最小互操作定义。基础客户端结构及 Dalamud API 由运行环境提供，不随安装包分发。
