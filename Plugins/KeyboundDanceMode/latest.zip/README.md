# 魔光键影炫舞模式

将魔光键影的头顶词条显示为 `↑`、`↓`、`←`、`→` 或 `[空格]`。看到提示后按下对应键，插件尝试完成一个匹配词条。

## 使用

在 Dalamud 第三方插件仓库设置中添加库链：

```text
https://raw.githubusercontent.com/Errerer/DalamudPlugins/main/pluginmaster.json
```

刷新插件列表后搜索“魔光键影炫舞模式”。手动加载开发构建时按以下步骤操作：

1. 将安装包解压到固定目录，在 Dalamud 的开发插件设置中添加 `KeyboundDanceMode.dll`，然后加载。
2. 如果同时使用 DailyRoutines，手动关闭“自动游玩魔光键影”和“自动支持魔光键影拼音输入”。检测到它们启用时，本插件会暂停并说明原因，不会调整 DR 设置。
3. 进入魔光键影后，直接按头顶提示使用普通方向键或空格，无需点击或聚焦副本输入框。
4. 使用 `/keybound` 打开设置，或用 `/keybound on`、`/keybound off` 启用、停用。

开发输出的 Debug 和 Release 目录均包含 DLL、同名加载清单和 `.deps.json`。保持三者在同一个目录，详情见 [加载文件与基础依赖](docs/loading.md)。

每次首次按下只尝试一次，长按不连续触发。空格直接对应词条，不作为确认键。数字小键盘不参与判定，组合快捷键不参与判定。

五个键均衡随机出现，空格与方向键同等参与。Boss、屏障等需要多次处理的目标，每次成功提交后立即更换为不同的键；同一词条每五次提示覆盖五个键。显示刷新或提交失败不会更换当前键，不需要等原版词条变化。

场上超过五个词条时会出现同键目标。同键时优先未满屏障，其次读条目标，最后普通目标；同级按出现顺序处理。头顶只显示方向键或 `[空格]`，当前优先目标通过颜色突出；实际提交前会重新检查目标状态。

未匹配按键只显示“未命中”。提交前会检查玩法状态、其他文本输入占用、禁止输入状态和原版动作锁；提交未被接受时需要玩家重新按键。屏障可能需要多次强化，敌人也可能需要多次攻击，“已提交”表示客户端接受本次动作，不代表整只敌人或整个机制已经结束。

游戏失去焦点、其他输入界面占用键盘、退出确认、停用或卸载时暂停输入接管并还原头顶文字。打开聊天或设置后如显示暂停，结束输入并关闭占用键盘的界面即可继续，无需将焦点切回副本输入框。

## 构建与测试

使用已配置的国服 Dalamud 开发环境：

```powershell
dotnet build KeyboundDanceMode.slnx --configuration Release
dotnet run --project KeyboundDanceMode.Tests/KeyboundDanceMode.Tests.csproj --configuration Release
powershell -ExecutionPolicy Bypass -File scripts/package.ps1
```

打包脚本默认构建 Release，指定 `-Configuration Debug` 可打包 Debug。产物按版本命名，当前 Debug 包为 `artifacts/KeyboundDanceMode-1.0.3.zip`，发布目录为 `DalamudPlugins/Plugins/KeyboundDanceMode/latest.zip`。开发加载使用 `KeyboundDanceMode/bin/Debug` 中的 DLL、加载清单和依赖文件。插件不依赖 DailyRoutines、OmenTools 或 FFXIVClientStructs.Expansion 的安装。

验证状态和游戏内验收清单见 [验证记录](docs/verification.md)。原生结构和签名来源见 [第三方说明](THIRD_PARTY_NOTICES.md)。
