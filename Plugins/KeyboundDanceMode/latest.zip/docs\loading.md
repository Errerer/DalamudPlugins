# 加载文件与基础依赖

## 可直接添加的开发插件路径

Debug：`KeyboundDanceMode/bin/Debug/KeyboundDanceMode.dll`

Release：`KeyboundDanceMode/bin/Release/KeyboundDanceMode.dll`

在 Dalamud 开发插件设置中添加其中一个 DLL。需要保持同目录下的文件完整，不要单独移动 DLL。

## 每份构建和安装包包含

| 文件 | 用途 |
| --- | --- |
| `KeyboundDanceMode.dll` | 插件入口、界面、五键判定及互操作实现 |
| `KeyboundDanceMode.json` | 名称、内部标识、程序集版本、API 等级及加载时机 |
| `KeyboundDanceMode.deps.json` | .NET 插件依赖描述，由构建自动生成 |

名称为“魔光键影炫舞模式”，内部标识和 DLL 文件名均为 `KeyboundDanceMode`，当前 Debug 程序集版本为 `1.0.3.0`。

构建会自动复制加载清单，检查上述三项产物存在。打包脚本另外检查清单与 DLL 的名称、版本一致，并检查依赖描述中列出的运行文件均存在；随后复制完整构建输出，避免漏掉之后新增的依赖或资源。

## 运行环境提供的依赖

使用国服 Dalamud API 15 开发插件环境。Dalamud 服务、基础 FFXIVClientStructs 和相关绑定由运行环境提供。本插件当前没有需要额外安装或打包的第三方运行库，也不依赖 DR、OmenTools 或 Expansion DLL。

配置由 Dalamud 的插件配置接口读取和保存，初次加载使用默认值；不需要手工创建配置 JSON。插件作为类库加载，不需要独立程序的 `runtimeconfig.json`。

检查输出目录：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/verify-load-files.ps1 -OutputFolder KeyboundDanceMode/bin/Debug
powershell -ExecutionPolicy Bypass -File scripts/verify-load-files.ps1 -OutputFolder KeyboundDanceMode/bin/Release
```

游戏内使用 `/keybound` 打开设置。具体机制和焦点行为由用户自行验证，见 `verification.md`。
